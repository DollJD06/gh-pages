
var x = [50, 50];
var p = [];


function setup() {
  createCanvas(400,400);
  background(46,144,255);
  fill(33,245,82);
  noStroke();
  rect(0,300,400,100)
  fill(255,235,41);
  noStroke();
  ellipse(350,50,x[0],x[1]);
  noStroke();
  fill(245,163,32);
  for (var i = 0; i <30; i++) {
  	p[i]=random  (20,40);
  }

}

function draw() {
 for(var i =0; i < x.length; i++) {
 	p[i] += .5;
 	var y = i * .4;
 	ellipse(p[i], y, 25,25 );
 }
 

}