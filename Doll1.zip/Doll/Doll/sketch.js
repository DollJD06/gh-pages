

function setup() {

	createCanvas(400, 400);
}

function draw() {

	background(100);

	// using a for loop, owl function is called until the x position is less than the width of the sketch plus 70 pixels

	for (var x = 35; x < width + 70; x += 70) {
		pacman(x, 110);
	}
}

function pacman(x, y) {

	push(); 

	translate(x, y);

	fill(255,255,0)

	ellipse(0, 0, 50, 50); //body of pacman

	fill(0);

	ellipse(0, -10, 8, 8); // eye

	fill(100)

	noStroke();

	triangle(0, 0, 30, 10, 30, -10,); // mouth  

	pop(); 

}



