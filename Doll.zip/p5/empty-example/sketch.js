var fixed;
var moveable;

function preload() {

	fixed = loadImage("skull.png");
	moveable = loadImage("star.png");
}

function setup() {
 createCanvas(500,500);
 background(125);
  // put setup code here
}

function draw() {
 image(fixed,0,0);
 image(moveable,mouseX,mouseY,);
 textSize(32);
 textFont("Arial");
 fill(0);
 stroke(255);
 text("Ahoy matey you've found a star!",0,425);
 textFont("Big Shoulders Inline Text");
 text("Move the mouse to locate it",0,500); // put drawing code here
}